<?php include("layouts/header.php"); ?>
<main class="container py-4">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Login</div>
                     <div class="card-body">

                        <form method="POST" action="login.php" id="loginForm1">
                             <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>
                                 <div class="col-md-6">
                                    <input id="email" type="email" name="email" value="" required="required" autocomplete="off" autofocus="autofocus" class="form-control ">
                                 </div>
                             </div>

                             <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right">Password</label>
                                 <div class="col-md-6">
                                    <input id="password" type="password" name="password" autocomplete="off" required="required"  class="form-control ">
                                </div>
                            </div>



                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn akame-btn">Login</button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal" id="loginModal" tabindex="-1" role="dialog">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">Fail</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Email or password is wrong.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include("layouts/footer.php"); ?>
<script>
    $(document).ready(function () {
        $("form#loginForm1").submit(function(e) {
            e.preventDefault();
            $.ajax({
                url: "login.php",
                data:{email: $("#email").val(),password: $("#password").val(),},
                type: "POST",
                success: function(data,status) {
                    //console.log(data);
                    if($.trim(data) == 'success'){
                        window.location.href = 'index.php';
                        console.log('Yes');
                    }else{
                        $('#loginModal').modal();
                        console.log('NO');
                    }
                }
            });

        });

    });
</script>