<?php
    include("conf/config.php");
    $name = $_POST['title'];
    $price = $_POST['price'];

    $sql = "INSERT INTO hair_care (
    hair_care_option, hair_care_price,
     create_at, update_at
    ) VALUES (
    '$name','$price', now(), now()
    )";
    mysqli_query($conn, $sql);
    header("location: hair-care-list.php");
?>
