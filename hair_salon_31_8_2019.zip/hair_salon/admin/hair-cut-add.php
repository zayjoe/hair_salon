<?php
    include("conf/config.php");
    $name = $_POST['title'];
    $price = $_POST['price'];

    $sql = "INSERT INTO hair_cut (
    hair_cut_title, hair_cut_price,
     create_at, update_at
    ) VALUES (
    '$name','$price', now(), now()
    )";
    mysqli_query($conn, $sql);
    header("location: hair-cut-list.php");
?>
