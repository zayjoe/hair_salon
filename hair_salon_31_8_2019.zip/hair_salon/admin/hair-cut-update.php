<?php
    include("conf/config.php");
    $id = $_POST['id'];
    $title = $_POST['title'];
    $price = $_POST['price'];

    $sql = "UPDATE hair_cut SET hair_cut_title='$title',hair_cut_price='$price',update_at=now() WHERE id = $id";

    mysqli_query($conn, $sql);
    header("location: hair-cut-list.php");
?>