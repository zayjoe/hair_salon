<?php
  include("conf/config.php");
  include("conf/auth.php");
  $name = $_POST['name'];
  $remark = $_POST['remark'];
  $image = $_FILES['image']['name'];
  $filename = pathinfo($image, PATHINFO_FILENAME);
  $fileExt = pathinfo($image, PATHINFO_EXTENSION);
  $file = $filename.'_'.time().'.'.$fileExt;

  $tmp = $_FILES['image']['tmp_name'];
    if($file) {
    move_uploaded_file($tmp, "images/$file");
  }

  $sql = "INSERT INTO stylists (stylist_name,remark,bimage,create_at,update_at) VALUES ('$name','$remark','$file',now(),now())";
  mysqli_query($conn, $sql);
  header("location: barber-list.php");
?>

