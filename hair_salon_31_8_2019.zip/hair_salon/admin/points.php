<?php
  include("conf/config.php");
  include("conf/auth.php");
  include ('admin-layouts/header.php');
?>
<div id="content-wrapper">
    <div class="container-fluid">

    <!-- Here Start the list of canteens -->
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Name</th>
              <th>Points</th>
              <th>Edit</th>
            </tr>
          </thead>
          <?php
            $sql = "SELECT points.*,users.name FROM users LEFT JOIN points ON points.user_id = users.id WHERE role != 'admin'";

            $result = mysqli_query($conn, $sql);
          ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['total'] ?></td>
            <td><a href="point-edit.php?id=<?php echo $row['id'] ?>"><button class="edit_btn btn info"><i class="fa fa-edit"></i>Edit</button></a> </td>
          </tr>
          <?php endwhile; ?>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
    <!-- Here End the list of canteens -->
    </div>
</div>
<?php include('admin-layouts/footer.php'); ?>