<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hair Salon - Dashboard</title>

    <!-- Bootstrap core CSS-->
    <link href="/hair_salon/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="/hair_salon/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="/hair_salon/css/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link rel="icon" href="favicon.png" type="image/x-icon"/>
    <link href="/hair_salon/css/sb-admin.min.css" rel="stylesheet">
    <link href="/hair_salon/css/admin-style.css" rel="stylesheet">


  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg_green static-top">

      <a class="navbar-brand mr-1" href="barber-list.php">Hair Salon</a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fa fa-bars"></i>
      </button>


      <!-- Navbar -->
      <ul class="nav ml-auto">
        <li class="">
          <a class="nav-link" href="logout.php">
            <i class="fa fa-sign-out"></i>
          </a>
        </li>
      </ul>
    </nav>
    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item ">
          <a class="nav-link" href="user-list.php">
            <i class="fa fa-user"></i>
            <span>User</span>
          </a>
        </li>
        <li class="nav-item ">
          <a class="nav-link" href="services-list.php">
          <i class="fa fa-scissors" aria-hidden="true"></i>
            <span>Service</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="barber-list.php">
          <i class="fa fa-users" aria-hidden="true"></i>
            <span>Style List</span></a>
        </li>

        <li class="nav-item ">
          <a class="nav-link" href="hair-cut-list.php">
          <i class="fa fa-list" aria-hidden="true"></i>
            <span>Hair Style</span>
          </a>
        </li>
        <li class="nav-item ">
          <a class="nav-link" href="hair-color-list.php">
          <i class="fa fa-list" aria-hidden="true"></i>
            <span>Hair Color</span>
          </a>
        </li>
        <li class="nav-item ">
          <a class="nav-link" href="hair-care-list.php">
          <i class="fa fa-list" aria-hidden="true"></i>
            <span>Hair Care</span>
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="admin-order.php">
            <i class="fa fa-fw fa-table"></i>
            <span>Orders</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="points.php">
          <i class="fa fa-trophy" aria-hidden="true"></i>
            <span>Point</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="contact-list.php">
          <i class="fa fa-envelope-o" aria-hidden="true"></i>
            <span>Contact</span></a>
        </li>

      </ul>
