<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_GET['id'];
    $sql = "DELETE FROM users WHERE id = $id";
    mysqli_query($conn, $sql);
    header("location: user-list.php");
?>
