<!DOCTYPE HTML>
<html lang="en-US">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/hair_salon/css/admin-login.css">

  <link rel="stylesheet" href="/hair_salon/css/bootstrap.min.css">
  <link rel="icon" href="favicon.png" type="image/x-icon"/>

</head>
<body>
  <div class="login_body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4">
                <div class="title_bar">
                Login to Control Panel
                </div>
                <form action="login.php" method="post" class="input_section">
                <div class="form-group">
                    <input type="email" class="form-control login-field" placeholder="Email" id="email" name="email">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control login-field last-field" placeholder="Your Password" id="password" name="password">
                </div>
                <input type="submit" class="submit-button correct" value="Admin Login"></input>
                </form>
            </div>
            <div class="col-4"></div>
        </div>

    </div>
  </div>
</body>
</html>
