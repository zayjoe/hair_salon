<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_GET['id'];
    $sql = "DELETE FROM contact_us WHERE id = $id";
    mysqli_query($conn, $sql);
    header("location: contact-list.php");
?>
