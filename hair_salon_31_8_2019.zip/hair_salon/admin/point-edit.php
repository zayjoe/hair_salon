<?php
    include("conf/config.php");
    include("conf/auth.php");
    include('admin-layouts/header.php');
    $id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM points WHERE id = $id");
    $row = mysqli_fetch_assoc($result);
?>
<div id="content-wrapper">
    <div class="container-fluid">

        <div class=" col-sm-8 text-left">

            <form action="point-update.php"class="fun_add" method="post">
            <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                <label for="name">Points</label>
                <input type="text" name="points" id="points" value="<?php echo $row['total']; ?>">

                <br><br>
                <input type="submit" value="Update Total">
            </form>

      </div>


    </div>
</div>

<? include('admin-layouts/footer.php'); ?>
