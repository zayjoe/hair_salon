<?php
  include("conf/config.php");
  include("conf/auth.php");
  include ('admin-layouts/header.php');
?>
<div id="content-wrapper">
    <div class="container-fluid">
    <a href="barber-new.php" class="new btn add_btn"><i class="fa fa-plus-circle"></i>New Style List</a>

    <!-- Here Start the list of canteens -->
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Remark</th>
              <th>Delete</th>
              <th>Edit</th>
            </tr>
          </thead>
          <?php
            $result = mysqli_query($conn, "SELECT * FROM stylists");
          ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td style="width:20px;"><img src="./images/<?php echo $row['bimage']; ?>"  class="img-thumbnail"></td>
            <td><?php echo $row['stylist_name'] ?></td>
            <td><?php echo $row['remark'] ?></td>
            <td><a href="barber-delete.php?id=<?php echo $row['id'] ?>"><button class="del_btn btn danger"> <i class="fa fa-trash"></i> Delete</button></a></td>
            <td><a href="barber-edit.php?id=<?php echo $row['id'] ?>"><button class="edit_btn btn info"><i class="fa fa-edit"></i>Edit</button></a> </td>
          </tr>
          <?php endwhile; ?>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
    <!-- Here End the list of canteens -->
    </div>
  </div>

  <?php include('admin-layouts/footer.php'); ?>