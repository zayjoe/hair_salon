<?php
  include("conf/config.php");
  include("conf/auth.php");
  include ('admin-layouts/header.php');
?>
<div id="content-wrapper">
    <div class="container-fluid">
    <a href="hair-color-new.php" class="new btn add_btn"><i class="fa fa-plus-circle"></i>New Hair Color</a>


    <!-- Here Start the list of canteens -->
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Hair Color Name</th>
              <th>Price</th>
              <th>Edit</th>
              <th>Delete</th>

            </tr>
          </thead>
          <?php
            $sql = "SELECT * FROM hair_color";

            $result = mysqli_query($conn, $sql);
          ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?php echo $row['hair_color_title'] ?></td>
            <td><?php echo $row['hair_color_price'] ?></td>
            <td><a href="hair-color-edit.php?id=<?php echo $row['id'] ?>"><button class="edit_btn btn info"><i class="fa fa-edit"></i>Edit</button></a> </td>
            <td><a href="hair-color-delete.php?id=<?php echo $row['id'] ?>"><button class="del_btn btn danger"><i class="fa fa-trash"></i>Delete</button></a> </td>

          </tr>
          <?php endwhile; ?>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
    <!-- Here End the list of canteens -->
    </div>
</div>


<?php include('admin-layouts/footer.php'); ?>