<?php
    if(!isset($_SESSION['auth_user'])) {
    header("location: https://www.google.com");
    exit();
    }
?>
