<?php
  include("conf/config.php");
  include("conf/auth.php");
  include('admin-layouts/header.php');
?>
    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
                </li>
                <li class="breadcrumb-item active">Barber</li>
            </ol>

            <div class=" col-sm-8 text-left">
                <form action="barber-add.php"class="fun_add" method="post" enctype="multipart/form-data">
                    <label for="name">Barber Name</label>
                    <input type="text" name="name" id="name">
                    <label for="remark">Remark</label>
                    <textarea name="remark" id="remark"style="width: 220px;border: 1px solid #90c322;border-radius: 5px;">
                    </textarea>

                    <div class="form-group">
                        <label for="image">Image</label>
                        <input type="file" class="form-control-file form-control-lg" name="image" id="image">
                    </div>
                    <br><br>
                    <input type="submit" value="Add Barber">
                </form>
            </div>


        </div>
    </div>


<? include('admin-layouts/footer.php'); ?>