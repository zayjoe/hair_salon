<?php include('layouts/header.php'); ?>
<div class="container msg_body">
    <div class="col-md-6">
        <div class="well">Thank you for your interest. we will contact you soon.</div>
        <button class="btn akame-btn"><a class="" href="index.php">Back to HOME</a></button>
        <br><br>
    </div>
</div>
<?php include('layouts/footer.php'); ?>