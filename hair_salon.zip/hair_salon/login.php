<?php
    include("admin/conf/config.php");
    //$pass = password_hash('1234', PASSWORD_DEFAULT);
    //echo $pass;

    $email = $_POST['email'];
    $password = trim($_POST['password']);


    $sql = "SELECT * FROM users WHERE email ='$email' ";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);

    //$hash =trim($row['password']) ;
    //echo $hash;
    //echo $row['email'];

    if(password_verify($password,$row['password']))
    {
        if($row['role'] != "admin"){
            $_SESSION['auth_user'] = true;
            $_SESSION['auth_user_id'] = $row['id'];

            echo "success";
            //header("location: index.php");

        }else {
            echo "fail";
        }

    }




?>
