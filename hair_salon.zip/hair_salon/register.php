<?php include("admin/conf/config.php");


    if(isset($_POST['name'])){
        $name = $_POST['name'];
        $password = $_POST['password'];
        $email = $_POST['email'];
        $pass = password_hash($password, PASSWORD_BCRYPT);
        $user_check = "SELECT * FROM users WHERE email = '$email' ";

         $result = mysqli_query($conn,$user_check);
         $count = mysqli_num_rows($result);

        if($count == 1){
            echo "usernameExit";
        }else {
            echo "Successfully";

            $user_add = "INSERT INTO users (name,email,password,role,create_at,update_at) VALUES ('$name','$email','$pass','bronze',now(),now())";
            mysqli_query($conn,$user_add);
            $user_id = mysqli_insert_id($conn);
            $_SESSION['auth_user'] = $user_id;
        }
    }

?>