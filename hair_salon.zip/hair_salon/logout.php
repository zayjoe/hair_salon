<?php
    session_start();
    unset($_SESSION['auth']);
    unset($_SESSION['auth_user']);
    unset($_SESSION['cart']);
    header("location: index.php");
?>

