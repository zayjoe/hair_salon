<?php
    if(!isset($_SESSION['auth_user'])) {
    header("location: ./hair_salon/index.php");
    exit();
    }
?>