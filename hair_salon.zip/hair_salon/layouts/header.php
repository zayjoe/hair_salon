<?php include('admin/conf/config.php');
	$barbers = mysqli_query($conn, "SELECT * FROM stylists");

    if(isset($_GET['cat'])) {
        $cat_id = $_GET['cat'];
        $services = mysqli_query($conn, "SELECT * FROM services WHERE stylist_id =
        $cat_id");
    } else {
        $products = mysqli_query($conn, "SELECT * FROM services");
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Title -->
    <title>Akame - Hair Salon HTML Template</title>

    <!-- Favicon -->
    <link rel="icon" href="./img/core-img/favicon.ico">

    <!-- Stylesheet -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader"></div>
    </div>
    <!-- /Preloader -->

    <!-- Header Area Start -->
    <header class="header-area">
        <!-- Top Header Area Start -->
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-5">
                        <div class="top-header-content">
                            <p>Welcome to hair salon!</p>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="top-header-content text-right">
                            <p><i class="fa fa-clock-o" aria-hidden="true"></i> Mon-Sat: 8.00 to 17.00 <span class="mx-2"></span> | <span class="mx-2"></span> <i class="fa fa-phone" aria-hidden="true"></i> Call us: (+12)-345-6789</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top Header Area End -->

        <!-- Main Header Start -->
        <div class="main-header-area">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Classy Menu -->
                    <nav class="classy-navbar justify-content-between" id="akameNav">

                        <!-- Logo -->
                        <a class="nav-brand" href="index.php"><img src="./img/core-img/logo.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">
                            <!-- Menu Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>
                            <!-- Nav Start -->
                            <div class="classynav">
                                <ul id="nav">
                                    <li class="active"><a href="./index.php">Home</a></li>
                                    <li><a href="#">Barber</a>
                                        <ul class="dropdown">
                                        <?php while($row = mysqli_fetch_assoc($barbers)): ?>
							                <li><a href="index.php?cat=<?php echo $row['id']; ?>"><?php echo $row['stylist_name']; ?></a></li>
						                <?php endwhile; ?>
                                            <!-- <li><a href="./barbers.html">- Barber One</a></li>
                                            <li><a href="#">- Barber Two</a></li>
                                            <li><a href="#">- Barber Three</a></li>
                                            <li><a href="#">- Barber Four</a></li> -->

                                        </ul>
                                    </li>

                                    <li><a href="./about.html">About Us</a></li>
                                    <li><a href="./contact.html">Contact Us</a></li>
                                     <li><?php echo isset($_SESSION['auth_user']) ? $user['name'] : ""; ?> (<span style="font-weight:bold;">Gold Member</span>)
                                     </li>

                                </ul>

                                <!-- Cart Icon -->
                                <div class="cart-icon ml-2 mt-4 mt-lg-0">
                                    <a href="#"><i class="icon_cart"></i></a>
                                </div>

                                <!-- Book Icon -->
                                <?php  if(!isset($_SESSION['auth_user'])):?>
                                <div class="book-now-btn ml-5 mt-4 mt-lg-0 ml-md-4">
                                    <a href="login-form.php" class="btn akame-btn">login</a>
                                </div>

                                <div class="book-now-btn ml-5 mt-4 mt-lg-0 ml-md-4">
                                    <a href="register-form.php" class="btn akame-btn">Sign Up</a>
                                </div>
                                <?php endif; ?>

                                <?php  if(isset($_SESSION['auth_user'])):?>
                                <div class="book-now-btn ml-5 mt-4 mt-lg-0 ml-md-4">
                                    <a href="logout.php" class="btn akame-btn">Log Out</a>
                                </div>
                                <?php endif; ?>
                            </div>
                            <!-- Nav End -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- Header Area End -->