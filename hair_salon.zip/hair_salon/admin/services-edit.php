<?php
  include("conf/config.php");
  include("conf/auth.php");
  include('admin-layouts/header.php');
  $id = $_GET['id'];
    $sql = "SELECT * FROM services WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
?>
    <div id="content-wrapper">
        <div class="container-fluid">

            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                Dashboard
                </li>
                <li class="breadcrumb-item active">Service Edit</li>
            </ol>

            <div class="col-sm-8">

                <form action="services-update.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
                    <div class="form-group">
                        <label for="name">Service Name</label>
                        <input type="text" name="title" class="form-control" placeholder="Enter Product" value="<?php echo $row['title'] ?>">
                    </div>

                    <div class="form-group">
                        <label for="name">Price</label>
                        <input type="text" name="price" class="form-control" placeholder="Enter Price" value="<?php echo $row['price']?>">
                    </div>

                    <div class="form-group">
                        <label for="categories">Barber</label>
                        <select class="form-control" name="stylist_id" id="canteens">
                            <?php
                                $can = mysqli_query($conn, "SELECT id, stylist_name FROM stylists");
                                while($row_can = mysqli_fetch_assoc($can)):
                            ?>
                            <option value="<?php echo $row_can['id'] ?>">
                            <?php echo $row_can['stylist_name'] ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label for="image">Image</label>
                        <img src="./images/<?php echo $row['image'] ?>" alt="" class="img-thumnail" style="width:15%;">
                        <input type="file" class="form-control-file form-control-lg" name="image" id="image">
                    </div>


                    <br><br>
                    <input type="submit" class="btn btn-success" value="Update Service">
                    <br><br>
                </form>
            </div>


        </div>
  </div>

<? include('admin-layouts/footer.php'); ?>