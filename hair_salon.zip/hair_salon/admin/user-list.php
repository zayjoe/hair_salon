<?php
  include("conf/config.php");
  include("conf/auth.php");
  include ('admin-layouts/header.php');
?>
    <div id="content-wrapper">
        <div class="container-fluid">
            <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered text-center" width="100%" cellspacing="0">
                <thead>
                    <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Delete</th>
                    <th>Edit</th>
                    </tr>
                </thead>
                <?php

                    $result = mysqli_query($conn, "SELECT * FROM users WHERE role != 'admin' ");
                ?>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['email'] ?></td>
                    <th><?php echo $row['role'] ?></th>

                    <td><a href="user-delete.php?id=<?php echo $row['id'] ?>"><button class="del_btn btn danger"> <i class="fa fa-trash"></i> Delete</button></a></td>
                    <td><a href="user-edit.php?id=<?php echo $row['id'] ?>"><button class="edit_btn btn info"><i class="fa fa-edit"></i>Edit</button></a> </td>
                </tr>
                <?php endwhile; ?>
                <tbody>

                </tbody>
                </table>
            </div>
            </div>
            <!-- Here End the list of canteens -->
        </div>
    </div>

<? include ('admin-layouts/footer.php'); ?>