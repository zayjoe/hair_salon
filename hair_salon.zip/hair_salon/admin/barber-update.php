<?php
    include("conf/config.php");
    include("conf/auth.php");
    $id = $_POST['id'];
    $name = $_POST['name'];
    $remark = $_POST['remark'];
    $sql = "UPDATE stylists SET stylist_name='$name', remark='$remark', update_at=now() WHERE id = '$id' ";
    mysqli_query($conn, $sql);
    header("location: barber-list.php");
?>
