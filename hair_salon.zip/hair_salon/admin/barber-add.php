<?php
  include("conf/config.php");
  include("conf/auth.php");
  $name = $_POST['name'];
  $remark = $_POST['remark'];
  $sql = "INSERT INTO stylists (stylist_name,remark,create_at,update_at) VALUES ('$name','$remark',now(),now())";
  mysqli_query($conn, $sql);
  header("location: barber-list.php");
?>

