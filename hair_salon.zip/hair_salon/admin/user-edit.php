<?php
  include("conf/config.php");
  include("conf/auth.php");
  include ('admin-layouts/header.php');
?>
<div id="content-wrapper">
    <div class="container-fluid">

        <?php
            $id = $_GET['id'];
            $result = mysqli_query($conn, "SELECT * FROM users WHERE id = $id");
            $row = mysqli_fetch_assoc($result);
        ?>

      <div class=" col-sm-8 text-left">

        <form action="user-update.php" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
            <div class="form-group">
                <label for="name">Name</label>
                <input class="form-control" type="text" name="name" id="name" value="<?php echo $row['name']; ?>">
            </div>

            <div class="form-group">
                <label for="name">Name</label>
                <input class="form-control" type="text" name="name" id="name" value="<?php echo $row['name']; ?>">
            </div>

            <div class="form-group">
                <label for="remark">Email</label>
                <input class="form-control" name="email" id="email" value="<?php echo $row['email']; ?>">
            </div>

            <div class="form-group">
                <label for="">Role</label>
                <input class="form-control" name="role" id="role" value="<?php echo $row['role']; ?>">
            </div>

            <br><br>
            <input type="submit" value="Update User">
        </form>

      </div>


    </div>
</div>

<? include ('admin-layouts/footer.php'); ?>